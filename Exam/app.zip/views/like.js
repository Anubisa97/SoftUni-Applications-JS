export function likeView(ctx) {
  console.log("like");
}
