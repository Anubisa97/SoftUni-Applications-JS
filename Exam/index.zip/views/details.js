import { html } from "../node_modules/lit-html/lit-html.js";
import { dataService } from "../src/dataServices.js";
import { userHelper } from "../src/userHelper.js";

const detailsTemp = (data, isOwner, isGuest) => html`
  <section id="details">
    <div id="details-wrapper">
      <img id="details-img" src="..${data.imageUrl}" alt="example1" />
      <div>
        <p id="details-category">${data.category}</p>
        <div id="info-wrapper">
          <div id="details-description">
            <p id="description">${data.description}</p>
            <p id="more-info">${data.moreInfo}</p>
          </div>
        </div>
        <h3>Is This Useful:<span id="likes">0</span></h3>
        ${
          isOwner
            ? html`
                <!--Edit and Delete are only for creator-->
                <div id="action-buttons">
                  <a href="/edit/${data._id}" id="edit-btn">Edit</a>
                  <a
                    @click=${delCharacter}
                    href="javascript:void(0)"
                    id="delete-btn"
                    >Delete</a
                  >
                </div>
              `
            : ""
        }
        

          <!--Bonus - Only for logged-in users ( not authors )-->
          <!--<a href="" id="like-btn">Like</a>-->
        </div>
      </div>
    </div>
  </section>
`;

let id = "";
let context = "";
export async function detailsView(ctx) {
  id = ctx.params.id;
  context = ctx;
  const data = await dataService.getSingleCharacter(id);
  const isOwner = userHelper.getUserID() === data._ownerId;
  const isGuest = userHelper.getUserData();
  ctx.render(detailsTemp(data, isOwner));
}

async function delCharacter() {
  if (confirm("Are you sure you want to delete the Character?") === true) {
    await dataService.delCharacter(id);
    context.goTo("/dashboard");
  }
}
