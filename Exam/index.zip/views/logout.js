export function logoutView(ctx) {
  console.log("logout");
}
